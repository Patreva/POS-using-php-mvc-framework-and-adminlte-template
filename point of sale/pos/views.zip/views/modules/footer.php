<footer class="main-footer">

	<strong>Copyright &copy; <span id="year"></span></strong>
	
	All rights reserved

</footer>
<script>
  $('#year').text(new Date().getFullYear());
</script>